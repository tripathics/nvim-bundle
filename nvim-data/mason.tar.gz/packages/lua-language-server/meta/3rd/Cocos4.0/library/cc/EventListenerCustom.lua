---@meta

---@class cc.EventListenerCustom :cc.EventListener
local EventListenerCustom = {}
cc.EventListenerCustom = EventListenerCustom

---*
---@return self
function EventListenerCustom:clone() end
---* / Overrides
---@return boolean
function EventListenerCustom:checkAvailable() end
---*  Constructor
---@return self
function EventListenerCustom:EventListenerCustom() end
