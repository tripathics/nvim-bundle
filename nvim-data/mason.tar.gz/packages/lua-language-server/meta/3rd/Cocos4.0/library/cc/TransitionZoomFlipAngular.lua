---@meta

---@class cc.TransitionZoomFlipAngular :cc.TransitionSceneOriented
local TransitionZoomFlipAngular = {}
cc.TransitionZoomFlipAngular = TransitionZoomFlipAngular

---@overload fun(float:float,cc.Scene:cc.Scene):self
---@overload fun(float:float,cc.Scene:cc.Scene,int:int):self
---@param t float
---@param s cc.Scene
---@param o int
---@return self
function TransitionZoomFlipAngular:create(t, s, o) end
---*
---@return self
function TransitionZoomFlipAngular:TransitionZoomFlipAngular() end
