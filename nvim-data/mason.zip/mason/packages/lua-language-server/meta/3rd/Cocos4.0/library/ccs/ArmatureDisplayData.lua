---@meta

---@class ccs.ArmatureDisplayData :ccs.DisplayData
local ArmatureDisplayData = {}
ccs.ArmatureDisplayData = ArmatureDisplayData

---*
---@return self
function ArmatureDisplayData:create() end
---* js ctor
---@return self
function ArmatureDisplayData:ArmatureDisplayData() end
