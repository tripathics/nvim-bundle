---@type conform.FileFormatterConfig
return {
  meta = {
    url = "https://github.com/itchyny/gojq",
    description = "Pure Go implementation of jq.",
  },
  command = "gojq",
}
