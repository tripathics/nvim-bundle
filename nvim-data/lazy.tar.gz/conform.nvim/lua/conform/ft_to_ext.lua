return {
  elixir = "ex",
  graphql = "gql",
  javascript = "js",
  javascriptreact = "jsx",
  markdown = "md",
  perl = "pl",
  python = "py",
  ruby = "rb",
  rust = "rs",
  typescript = "ts",
  typescriptreact = "tsx",
}
