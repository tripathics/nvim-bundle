# Terminal (term)

See the [reference configuration](../configuration/reference.md#term) for the complete list of options.

TODO
