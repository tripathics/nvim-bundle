text

<!-- comment -->

```lua
local foo = 'bar'
```


<!-- comment -->

```lua
local foo = 'bar'
local bar = 3
```
