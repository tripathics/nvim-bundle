---@type conform.FileFormatterConfig
return {
  meta = {
    url = "https://github.com/haskell/stylish-haskell",
    description = "Haskell code prettifier.",
  },
  command = "stylish-haskell",
  args = {},
  stdin = true,
}
