return {
  meta = {
    url = "https://github.com/fables-tales/rubyfmt",
    description = "Ruby Autoformatter! (Written in Rust)",
  },
  command = "rubyfmt",
}
