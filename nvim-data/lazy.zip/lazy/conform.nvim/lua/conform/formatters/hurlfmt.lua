---@type conform.FileFormatterConfig
return {
  meta = {
    url = "https://hurl.dev/",
    description = "Formats hurl files.",
  },
  command = "hurlfmt",
}
